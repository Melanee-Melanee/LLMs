This dataset is a subset of the Open Assistant dataset, which you can find here: https://huggingface.co/datasets/OpenAssistant/oasst1/tree/main

This subset of the data only contains the highest-rated paths in the conversation tree, with a total of 9,846 samples.

This dataset was used to train Guanaco with QLoRA.

For further information, please see the original dataset.

License: Apache 2.0